package com.example.mastergame.api;

public class KeyConstanChat {
    public static Long appID = 1671772552L;
    public static String appSing = "a233f298c67ccb771d877453dd26d16eb90c81ad26d85f750192b04d24dd005a";


}

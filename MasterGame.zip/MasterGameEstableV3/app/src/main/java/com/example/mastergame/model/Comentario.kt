package com.example.mastergame.model

data class Comentario (var imagen: Int, var nombreUsuario: String,
                       var fecha: String, val comentarioEscrito: String,
                       /* val id_usuario: String, val id_video: String*/)
package com.example.mastergame.model

import com.example.mastergame.R

class ComentarioProvider {

    companion object{

        val listaComentarios = mutableListOf<Comentario>(

            Comentario(R.drawable.perfilusertransparente, "Usuario1","01/01/2024", "Esto es una prueba de comentario"),
            Comentario(R.drawable.perfilusertransparente, "Usuario2","02/01/2024", "Esto es una prueba de comentario"),
            Comentario(R.drawable.perfilusertransparente, "Usuario3","03/01/2024", "Esto es una prueba de comentario"),
            Comentario(R.drawable.perfilusertransparente, "Usuario4","04/01/2024", "Esto es una prueba de comentario"),
            Comentario(R.drawable.perfilusertransparente, "Usuario5","05/01/2024", "Esto es una prueba de comentario"),
            Comentario(R.drawable.perfilusertransparente, "Usuario6","06/01/2024", "Esto es una prueba de comentario"),
            Comentario(R.drawable.perfilusertransparente, "Usuario7","07/01/2024", "Esto es una prueba de comentario"),
            Comentario(R.drawable.perfilusertransparente, "Usuario8","08/01/2024", "Esto es una prueba de comentario"),
            Comentario(R.drawable.perfilusertransparente, "Usuario9","09/01/2024", "Esto es una prueba de comentario"),
            Comentario(R.drawable.perfilusertransparente, "Usuario10","10/01/2024", "Esto es una prueba de comentario")

        )





    }

}
package com.example.mastergame.model

data class Source(
    val id: String,
    val name: String
)
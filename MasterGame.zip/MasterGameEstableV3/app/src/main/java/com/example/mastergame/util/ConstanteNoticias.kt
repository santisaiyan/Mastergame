package com.example.mastergame.util

import com.example.mastergame.adapter.CategoriasAdapter

class ConstanteNoticias {
    companion object{
        const val API_KEY="fc7cf7f4fb04415480a453a784aeef54"
        const val Base_URL= "https://newsapi.org/"
        const val SEARCH_NEWS_TIME_DELAY= 500L
        const val QUERY_PAGE_SIZE= 20
    }
}